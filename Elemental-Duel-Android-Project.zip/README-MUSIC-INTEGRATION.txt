ELEMENTAL DUEL — MUSIC INTEGRATION (v1.0.2-dev)

Tracks:
- ED_MainTheme_01.wav -> assets/audio/ed-main-theme.mp3 (main menu)
- ED_AncientMysteries_02.wav -> assets/audio/ed-ancient-mysteries.mp3 (menus/exploration)
- ED_SixRealms_03.wav -> assets/audio/ed-six-realms.mp3 (battles)

The original WAV files were not modified. MP3 files are optimized playback copies.
Music settings are stored separately from player profiles in WebView localStorage.
The development APK uses package ID com.elementalduel.app.dev to avoid overwriting
the public v1.0.1 app and its local saves.
