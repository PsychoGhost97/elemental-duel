Elemental Duel Android project - official launcher icon fix

This archive includes the Android app source and the official launcher icon resources.
The AndroidManifest.xml explicitly points android:icon and android:roundIcon to @mipmap/ic_launcher.
Version bumped to 1.0.1 (versionCode 2) for installing as an update over the previous test APK.

Upload this ZIP to the GitHub repository root, replacing the old Elemental-Duel-Android-Project.zip.
Keep Elemental-Duel-Icon-Resources.zip in the repository root if the current workflow still extracts it.
Then commit and let the existing Build Elemental Duel APK workflow run.
