# Elemental Duel — Android wrapper project

This project wraps the offline Awakening Update HTML in a native Android WebView.
The game HTML is bundled locally in `app/src/main/assets/index.html`; no hosted
website or network connection is required for gameplay.

## Build an APK with GitHub Actions

1. Copy the `android-app` folder into the root of your `elemental-duel` GitHub repo.
2. Copy the included `.github` folder into the root of that repo too.
3. Commit and push the files.
4. Open the repository's **Actions** tab.
5. Run **Build Elemental Duel APK** using **Run workflow**.
6. Download the `Elemental-Duel-debug-apk` artifact from the completed run.
7. Extract the ZIP and install the APK on Android. If Android asks, allow installs
   from the browser or file manager used to open it.

This produces a debug APK for testing. A Play Store release needs a separately
generated, securely stored signing key and a signed release build.

## Notes

- Package ID: `com.elementalduel.app`
- Minimum Android: Android 6.0 (API 23)
- Saves use browser local storage inside the app's WebView.
- Uninstalling the app or clearing its storage can erase local saves; export
  profile backups from inside the game before doing either.
- The source HTML is also preserved separately as a standalone file.
