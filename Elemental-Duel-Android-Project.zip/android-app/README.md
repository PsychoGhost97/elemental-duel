# Elemental Duel — Android wrapper project

This development project wraps the offline Elemental Duel HTML and original background soundtrack in a native Android WebView.

## Music integration

- Main menu: `ED_MainTheme_01` (MP3 optimized from the original WAV)
- Exploration and menus: `ED_AncientMysteries_02`
- Battles: `ED_SixRealms_03`
- Music can be enabled/disabled and its volume adjusted in Settings.
- Playback begins after the player's first tap because Android WebView requires a user gesture for audio playback.
- Original WAV master files are preserved separately; the APK uses compressed MP3 copies.
The game HTML is bundled locally in `app/src/main/assets/index.html`; no hosted
website or network connection is required for gameplay.

## Build an APK with GitHub Actions

1. Copy the `android-app` folder into the root of your `elemental-duel` GitHub repo.
2. Copy the included `.github` folder into the root of that repo too.
3. Commit and push the files.
4. Open the repository's **Actions** tab.
5. Run **Build Elemental Duel APK** using **Run workflow**.
6. Download the `Elemental-Duel-debug-apk` artifact from the completed run.
7. Extract the ZIP and install the APK on Android. If Android asks, allow installs
   from the browser or file manager used to open it.

This produces a debug APK for testing. A Play Store release needs a separately
generated, securely stored signing key and a signed release build.

## Notes

- Development package ID: `com.elementalduel.app.dev` (installs alongside the stable public app)
- Development version: `1.0.2-dev`
- Minimum Android: Android 6.0 (API 23)
- Saves use browser local storage inside the app's WebView.
- Uninstalling the app or clearing its storage can erase local saves; export
  profile backups from inside the game before doing either.
- The source HTML and compressed music assets are bundled in `app/src/main/assets/`.
